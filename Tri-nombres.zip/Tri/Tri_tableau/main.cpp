#include <iostream>
#include<vector>
#include<algorithm>

using namespace std;
template<class T>
void tableau_tri(vector<T> &tableau,int n)
{
    T valeur;
    for(int i=0;i<n;i++)
        {
            cout<<"Entrez la  valeur : "<<endl;
            cin>>valeur;
            tableau.push_back(valeur);
        }

  sort(tableau.begin(),tableau.end());

  cout<<"Tableau trier par ordre croissant "<<endl;
    for(int i=0;i<tableau.size();i++)
    {
        cout<<tableau[i]<<endl;
    }
}

int main()
{

    vector<int> table_tri;
    int n;
    cout<<"Quelle est la taille de votre tableau : "<<endl;
    cin>>n;
tableau_tri(table_tri,n);
    return 0;
}

